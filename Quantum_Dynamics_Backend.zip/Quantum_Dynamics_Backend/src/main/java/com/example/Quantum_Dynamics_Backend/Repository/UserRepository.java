package com.example.Quantum_Dynamics_Backend.Repository;

import java.math.BigInteger;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.Quantum_Dynamics_Backend.DAO.Users;

public interface UserRepository extends JpaRepository<Users,BigInteger>{
    Optional<Users>  findByUsername(String username);
}
