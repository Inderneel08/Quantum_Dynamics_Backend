package com.example.Quantum_Dynamics_Backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QuantumDynamicsBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(QuantumDynamicsBackendApplication.class, args);
	}

}
