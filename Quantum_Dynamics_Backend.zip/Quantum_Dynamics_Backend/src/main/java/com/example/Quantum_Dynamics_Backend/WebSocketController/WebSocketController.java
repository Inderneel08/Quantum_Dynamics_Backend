package com.example.Quantum_Dynamics_Backend.WebSocketController;

import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(origins = "http://localhost:3000/")
@RestController
public class WebSocketController {

    @MessageMapping("/loggedin")
    @SendTo("/topic/loggedin")
    public ResponseEntity<?> sendLoginMessage(String message) {
        return (ResponseEntity.ok().body(message));
    }

    @MessageMapping("/disconnect")
    @SendTo("/topic/disconnect")
    public ResponseEntity<?> handleDisconnectEntity(@RequestBody Map<String, String> request) {
        return(ResponseEntity.ok().body(request.get("username") + " logged out"));
    }

}
