package com.example.Quantum_Dynamics_Backend.Jwt;

import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.Quantum_Dynamics_Backend.DAO.Users;
import com.example.Quantum_Dynamics_Backend.Repository.UserRepository;

@CrossOrigin(origins = "http://localhost:3000/")
@RestController
public class JwtController {

    @Autowired
    private UserDetailsService userDetailsService;

    @Autowired
    private JwtTokenProvider jwtTokenProvider;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private Users users;

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody Map<String, String> jwtRequest)
    {
        System.out.println(jwtRequest);

        if(userDetailsService.loadUserByUsername(jwtRequest.get("username")).getUsername()!=null){
            return ResponseEntity.badRequest().body("User already exists...");
        }

        users.setName(jwtRequest.get("name"));
        users.setUsername(jwtRequest.get("username"));
        users.setPassword(passwordEncoder.encode(jwtRequest.get("password")));
        
        userRepository.save(users);

        return(ResponseEntity.ok().body("User created..."));
    }

    @PostMapping("/login")
    public ResponseEntity<?> generateToken(@RequestBody Map<String, String> jWtrequest) {
        UserDetails userDetails = userDetailsService.loadUserByUsername(jWtrequest.get("username"));

        System.out.println(userDetails.getUsername());
        System.out.println(userDetails.getPassword());

        if(userDetails.getUsername()==null){
            return (ResponseEntity.status(401).body("Username is not registered"));
        }

        if (!BCrypt.checkpw(jWtrequest.get("password"), userDetails.getPassword())) {

            return (ResponseEntity.status(401).body("Incorrect Password"));
        }

        String generatedToken = jwtTokenProvider.generateToken(userDetails);

        System.out.println("JWT token " + generatedToken);

        return ResponseEntity.ok(new JwtToken(jWtrequest.get("email"),generatedToken));
    }

    // @PostMapping("/adminLogin")
    // public void generateTokenForAdmin(@RequestBody Map<String, String> jWtrequest)
    // {
    //     System.out.println(jWtrequest);

    //     System.out.println(jWtrequest.get("email"));
    // }


    // @GetMapping("/validate")
    // public ResponseEntity<?> validateTokenIdentity()
    // {
    //     return(ResponseEntity.ok("VALIDATED"));
    // }

}
