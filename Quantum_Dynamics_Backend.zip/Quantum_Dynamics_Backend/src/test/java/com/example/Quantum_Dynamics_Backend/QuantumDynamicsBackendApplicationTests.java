package com.example.Quantum_Dynamics_Backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuantumDynamicsBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
